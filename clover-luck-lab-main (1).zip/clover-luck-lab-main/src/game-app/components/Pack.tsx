// @ts-nocheck
import { useState } from "react";
import { buffActive, type Save } from "../game/data";
import { ITEMS, ITEM_BY_ID, KIND_LABEL, RARITY_COLORS, RARITY_NAMES, formatCountdown, type ItemDef, type ItemKind } from "../game/market";
import { Block, BlockButton, PixelIcon } from "./ui";
import { Modal } from "./panels";
import { ItemTip } from "./ItemTip";
import { useNow } from "./useNow";

const SLOT_COLUMNS = 4;
const MIN_SLOTS = 12;
const USE_LABEL: Record<ItemKind, string> = { potion: "DRINK", charm: "EQUIP", tool: "USE" };

/** Active effects, the owned-item grid, and a detail card for whatever is picked. */
function PackView({ save, onUse, onUnequip }: { save: Save; onUse: (id: string) => void; onUnequip: (id: string) => void }) {
  const now = useNow(1000);
  const [picked, setPicked] = useState<string | null>(null);
  
  const owned = ITEMS.filter((item) => (save.inventory[item.id] ?? 0) > 0)
    .sort((a, b) => b.rarity - a.rarity || a.name.localeCompare(b.name));
  const buffs = ITEMS.filter((item) => item.duration && buffActive(save, item.id, now));
  
  // All charms equipped in loadout slots
  const equipped = (save.equippedCharms ?? []).map((id) => ITEM_BY_ID[id]).filter((x): x is ItemDef => !!x);
  const selectedIsEquipped = (save.equippedCharms ?? []).includes(picked ?? "");
  const current = ITEM_BY_ID[picked ?? ""] || owned.find((item) => item.id === picked);
  
  const totalOwned = owned.reduce((sum, item) => sum + (save.inventory[item.id] ?? 0), 0);
  const slotCount = Math.max(MIN_SLOTS, Math.ceil(owned.length / SLOT_COLUMNS) * SLOT_COLUMNS);
  const slots = Array.from({ length: slotCount }, (_, i): ItemDef | undefined => owned[i]);
  const activeBattery = save.perks.battery ?? 0;
  const quiet = buffs.length === 0 && equipped.length === 0 && activeBattery === 0;

  return (
    <div className="pk">
      <div className="pk-status">
        {quiet && <span className="tx-label pk-none">NO ACTIVE EFFECTS</span>}
        {buffs.map((item) => (
          <span className="pk-buff animate-fadein" key={item.id}>
            <PixelIcon name={item.icon} className="pk-buff-icon" />
            <span className="tx-label">{item.name}</span>
            <b className="tx-stroke">{formatCountdown((save.buffs[item.id] ?? 0) - now)}</b>
          </span>
        ))}
        {activeBattery > 0 && (
          <span className="pk-buff animate-fadein">
            <PixelIcon name="battery" className="pk-buff-icon" />
            <span className="tx-label">OVERCLOCK</span>
            <b className="tx-stroke">x{activeBattery}</b>
          </span>
        )}
      </div>

      {/* Active Loadout: 3 slots for equippable passive charms */}
      <div className="pk-case pk-loadout">
        <div className="pk-case-head">
          <span className="tx-stroke">ACTIVE CHARMS</span>
          <span className="tx-label">{equipped.length}/3 EQUIPPED</span>
        </div>
        <div className="pk-loadout-grid">
          {Array.from({ length: 3 }, (_, i) => {
            const item = equipped[i];
            return item ? (
              <ItemTip key={item.id} item={item} className="pk-slot-wrap">
                <button
                  type="button"
                  className={`pk-slot is-equipped${picked === item.id ? " is-selected" : ""}`}
                  data-rarity={item.rarity}
                  onClick={() => setPicked(item.id)}
                  aria-pressed={picked === item.id}
                  aria-label={`${item.name} equipped. ${item.blurb}`}
                >
                  <PixelIcon name={item.icon} className="pk-icon" />
                  <span className="tx-stroke pk-equipped-tag">EQ</span>
                </button>
              </ItemTip>
            ) : (
              <span key={`empty-${i}`} className="pk-slot is-empty" aria-hidden="true" />
            );
          })}
        </div>
      </div>

      <div className="pk-case">
        <div className="pk-case-head">
          <span className="tx-stroke">ITEM CASE</span>
          <span className="tx-label">{owned.length} TYPES / {totalOwned} TOTAL</span>
        </div>
        <div className="pk-grid" aria-label="Owned items">
          {slots.map((item, i) => item ? (
            <ItemTip key={item.id} item={item} className="pk-slot-wrap">
              <button
                type="button"
                className={`pk-slot${picked === item.id ? " is-selected" : ""}`}
                data-rarity={item.rarity}
                onClick={() => setPicked(item.id)}
                aria-pressed={picked === item.id}
                aria-label={`${item.name}, owned ${save.inventory[item.id]}. ${item.blurb}`}
              >
                <PixelIcon name={item.icon} className="pk-icon" />
                <span className="tx-stroke pk-count">{save.inventory[item.id]}</span>
              </button>
            </ItemTip>
          ) : (
            <span key={`empty-${i}`} className="pk-slot is-empty" aria-hidden="true" />
          ))}
        </div>
      </div>

      {current ? (
        <Block tone="metal" className="pk-detail animate-fadein" faceClassName="pk-detail-face">
          <div className="pk-detail-head">
            <span className="pk-detail-icon"><PixelIcon name={current.icon} className="pk-detail-art" /></span>
            <div className="pk-detail-text">
              <span className="tx-stroke pk-detail-name">{current.name}</span>
              <span className="tx-label" style={{ color: RARITY_COLORS[current.rarity] }}>
                {RARITY_NAMES[current.rarity]} / {KIND_LABEL[current.kind]}
                {selectedIsEquipped ? " / EQUIPPED" : ` / OWNED x${save.inventory[current.id] ?? 0}`}
              </span>
            </div>
          </div>
          <span className="tx-label pk-blurb">{current.blurb}</span>
          <span className="tx-stroke pk-effect">{current.effect}</span>
          {selectedIsEquipped ? (
            <BlockButton tone="red" className="pk-use animate-fadein" faceClassName="pk-use-face" onClick={() => onUnequip(current.id)} aria-label={`Unequip ${current.name}`}>
              <span className="tx-stroke">UNEQUIP</span>
            </BlockButton>
          ) : (
            <BlockButton
              tone={(current.kind === "charm" && equipped.length >= 3) ? "metal" : "green"}
              disabled={current.kind === "charm" && equipped.length >= 3}
              className="pk-use animate-fadein"
              faceClassName="pk-use-face"
              onClick={() => onUse(current.id)}
              aria-label={`${USE_LABEL[current.kind]} ${current.name}`}
            >
              <span className="tx-stroke">
                {current.kind === "charm" ? (equipped.length >= 3 ? "SLOTS FULL" : "EQUIP") : USE_LABEL[current.kind]}
              </span>
            </BlockButton>
          )}
        </Block>
      ) : (
        <span className="tx-label pk-hint">{owned.length || equipped.length ? "SELECT AN ITEM TO VIEW IT" : "EMPTY. VISIT THE MERCHANT FOR POTIONS AND CHARMS."}</span>
      )}
    </div>
  );
}

/** The pack window, opened from the button under the roll button. */
export function PackModal({ save, onUse, onUnequip, onClose }: { save: Save; onUse: (id: string) => void; onUnequip: (id: string) => void; onClose: () => void }) {
  return (
    <Modal
      title="PACK"
      headTone="tint"
      headHue={199}
      icon="pack"
      onClose={onClose}
      className="pack-modal"
      footer={<span className="tx-label">DRINK POTIONS TO GAIN BUFFS · EQUIP PASSIVE CHARMS IN YOUR LOADOUT SLOTS.</span>}
    >
      <PackView save={save} onUse={onUse} onUnequip={onUnequip} />
    </Modal>
  );
}
