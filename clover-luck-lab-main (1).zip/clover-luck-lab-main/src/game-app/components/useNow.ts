// @ts-nocheck
import { useEffect, useState } from "react";

/** Returns the current time, refreshed every `intervalMs`, so countdowns and buff timers stay live. */
export function useNow(intervalMs = 1000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(id);
  }, [intervalMs]);
  return now;
}
