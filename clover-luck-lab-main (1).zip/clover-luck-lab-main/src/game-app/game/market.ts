// @ts-nocheck
/**
 * Merchant: a stall that restocks on a timer, plus the potions, charms and tools it sells.
 * Stock is weighted so rare potions and charms show up in only a tiny share of restocks.
 */
import type { IconName } from "./icons";
import { MERCHANT_SLOTS, restockIntervalMs, type MerchantSlot, type Save, type Variant, foundKey } from "./data";

export type ItemKind = "potion" | "charm" | "tool";

export type ItemDef = {
  id: string;
  name: string;
  kind: ItemKind;
  /** Index into RARITY_NAMES. */
  rarity: number;
  icon: IconName;
  color: string;
  /** Relative chance of appearing in one stock slot. Rare items are fractions of a percent. */
  weight: number;
  price: number;
  /** Timed effects only: how long the buff lasts, in ms. */
  duration?: number;
  blurb: string;
  effect: string;
};

export const RARITY_NAMES = ["COMMON", "UNCOMMON", "RARE", "EPIC", "LEGENDARY", "MYTHIC"];
export const RARITY_COLORS = ["#c8d6df", "#3ff2c0", "#73d7ff", "#c07bff", "#ffd23f", "#ff6782"];
export const RARITY_HUE = [131, 162, 199, 272, 45, 352];
export const KIND_LABEL: Record<ItemKind, string> = { potion: "POTION", charm: "CHARM", tool: "TOOL" };

const MIN = 60 * 1000;

export const ITEMS: ItemDef[] = [
  { id: "luckElixir", name: "LUCK POTION", kind: "potion", rarity: 0, icon: "potionLuck", color: "#3dff8a", weight: 230, price: 1500, duration: 3 * MIN, blurb: "Doubles your luck for 3 minutes. Drinking another adds 3 more minutes.", effect: "LUCK x2 FOR 3 MIN" },
  { id: "gilded", name: "VALUE POTION", kind: "potion", rarity: 0, icon: "potionGild", color: "#ff5fd0", weight: 200, price: 3000, duration: 3 * MIN, blurb: "Every clover you roll pays double for 3 minutes.", effect: "VALUE x2 FOR 3 MIN" },
  { id: "quickstep", name: "SPEED POTION", kind: "potion", rarity: 1, icon: "potionSwift", color: "#6fe8ff", weight: 170, price: 2600, duration: 3 * MIN, blurb: "Cuts the roll cooldown in half for 3 minutes.", effect: "COOLDOWN HALVED 3 MIN" },
  { id: "sunfire", name: "CRIT POTION", kind: "potion", rarity: 1, icon: "vialFire", color: "#ff7a2e", weight: 110, price: 9000, duration: 2 * MIN, blurb: "Adds +30% crit chance for 2 minutes. Crits pay 10x.", effect: "CRIT +30% FOR 2 MIN" },
  { id: "potionMulti", name: "SIZE POTION", kind: "potion", rarity: 1, icon: "potionMulti", color: "#ffa33f", weight: 80, price: 15000, duration: 3 * MIN, blurb: "Temporary +1 rolls per click for 3 minutes.", effect: "+1 ROLL/CLICK 3 MIN" },
  { id: "caravanToken", name: "RESTOCK TOKEN", kind: "tool", rarity: 1, icon: "tokenCaravan", color: "#e0a84e", weight: 120, price: 14000, blurb: "Restocks the merchant right now with 5 new items.", effect: "RESTOCK NOW" },
  { id: "timeSand", name: "HOURGLASS", kind: "tool", rarity: 2, icon: "sandVial", color: "#f0d28a", weight: 45, price: 40000, blurb: "Takes 5 minutes off the merchant's restock timer.", effect: "-5 MIN ON RESTOCK" },
  { id: "kettle", name: "BREWMASTER POT", kind: "tool", rarity: 2, icon: "kettle", color: "#c79a5b", weight: 45, price: 35000, blurb: "Double-brews: instantly doubles the active duration of your current potion buffs.", effect: "DOUBLE BUFF DURATIONS" },
  { id: "battery", name: "VOLTAIC CELL", kind: "tool", rarity: 3, icon: "battery", color: "#b6ff6a", weight: 20, price: 60000, blurb: "Overclocks: your next 100 rolls are completed 3x faster.", effect: "100 ROLLS 3x FASTER" },
  { id: "philterStar", name: "STAR POTION", kind: "potion", rarity: 4, icon: "philterStar", color: "#c8b8ff", weight: 0.3, price: 350000, duration: 90 * 1000, blurb: "Luck x5 and value x2 for 90 seconds. Stacks with other potions.", effect: "LUCK x5 + VALUE x2, 90 SEC" },
  { id: "horseshoe", name: "GOLD HORSESHOE", kind: "charm", rarity: 2, icon: "horseshoe", color: "#ffd23f", weight: 30, price: 120000, blurb: "Constellation horseshoe. Equip in a loadout slot to gain passives.", effect: "+15% LUCK WHEN EQUIPPED" },
  { id: "magnet", name: "CLOVER MAGNET", kind: "charm", rarity: 1, icon: "magnet", color: "#3d8aff", weight: 40, price: 30000, blurb: "Strong magnet. Equip in a loadout slot to gain passives.", effect: "+20% VALUE WHEN EQUIPPED" },
  { id: "lodestone", name: "SHINY LODESTONE", kind: "charm", rarity: 2, icon: "lodestone", color: "#ffa040", weight: 30, price: 50000, blurb: "Iron mineral. Equip in a loadout slot to gain passives.", effect: "+25% SHINY WHEN EQUIPPED" },
  { id: "cursedEye", name: "CURSED EYE", kind: "charm", rarity: 3, icon: "cursedEye", color: "#ff3fb8", weight: 15, price: 100000, blurb: "Eyeball cursed by void. Equip in a loadout slot to gain passives.", effect: "+35% CURSE, -10% LUCK" },
  { id: "emeraldRing", name: "EMERALD RING", kind: "charm", rarity: 2, icon: "emeraldRing", color: "#3ff2c0", weight: 50, price: 40000, blurb: "Gemstone band. Equip in a loadout slot to gain passives.", effect: "+10% CRIT WHEN EQUIPPED" },
  { id: "crystalShard", name: "CRYSTAL SHARD", kind: "charm", rarity: 3, icon: "crystalShard", color: "#73d7ff", weight: 25, price: 80000, blurb: "Icy quartz shard. Equip in a loadout slot to gain passives.", effect: "+30% CRYSTAL WHEN EQUIPPED" },
  { id: "gearTooth", name: "GEAR TOOTH", kind: "charm", rarity: 1, icon: "gearTooth", color: "#a9b5bf", weight: 70, price: 20000, blurb: "Clockwork tooth. Equip in a slot to gain passives.", effect: "-12% MANUAL COOLDOWN" },
  { id: "silverBell", name: "SILVER BELL", kind: "charm", rarity: 1, icon: "silverBell", color: "#dfe6ee", weight: 65, price: 25000, blurb: "Polished bell. Equip in a slot to gain passives.", effect: "+20% RESTOCK SPEED" },
  { id: "luckyCharm", name: "LUCKY AMULET", kind: "charm", rarity: 4, icon: "luckyCharm", color: "#ffdf3f", weight: 12, price: 350000, blurb: "Polished amulet. Equip in a slot to gain passives.", effect: "+10% LUCK & +10% VALUE" },
  { id: "cloverCompass", name: "WANDER COMPASS", kind: "charm", rarity: 3, icon: "cloverCompass", color: "#e0a84e", weight: 18, price: 250000, blurb: "Ancient compass. Equip in a slot to gain passives.", effect: "15% ITEM FIND CHANCE" },
];

export const ITEM_BY_ID: Record<string, ItemDef | undefined> = Object.fromEntries(ITEMS.map((item) => [item.id, item]));

/**
 * Exact chance that each item appears at least once in a five-item restock.
 * Stock uses weighted draws without replacement (the same Plackett-Luce
 * process as rollStock); the subset DP here mirrors those probabilities.
 */
export function restockOdds(): Record<string, number> {
  const n = ITEMS.length;
  const full = 1 << n;
  const totalWeight = ITEMS.reduce((sum, item) => sum + item.weight, 0);
  let states = new Float64Array(full);
  states[0] = 1;
  const included = new Float64Array(n);

  for (let draw = 0; draw < Math.min(MERCHANT_SLOTS, n); draw++) {
    const next = new Float64Array(full);
    for (let mask = 0; mask < full; mask++) {
      const pathChance = states[mask];
      if (!pathChance) continue;
      let remainingWeight = totalWeight;
      for (let i = 0; i < n; i++) if (mask & (1 << i)) remainingWeight -= ITEMS[i].weight;
      for (let i = 0; i < n; i++) {
        const bit = 1 << i;
        if (mask & bit) continue;
        const transition = pathChance * ITEMS[i].weight / remainingWeight;
        next[mask | bit] += transition;
        included[i] += transition;
      }
    }
    states = next;
  }

  return Object.fromEntries(ITEMS.map((item, index) => [item.id, included[index]]));
}

export function formatRestockChance(probability: number): string {
  const percent = probability * 100;
  if (percent >= 10) return `${percent.toFixed(1)}%`;
  if (percent >= 1) return `${percent.toFixed(2)}%`;
  if (percent >= 0.01) return `${percent.toFixed(3)}%`;
  return `${percent.toFixed(4)}%`;
}

/** True when the stall has no stock yet, or its restock time has arrived. */
export const merchantDue = (s: Save, now = Date.now()) => s.merchant.stock.length === 0 || now >= s.merchant.nextRestockAt;

const pickItem = (taken: Set<string>): ItemDef => {
  // Draw only from items still available, matching the odds table's exact
  // weighted-without-replacement model even on the final stock slots.
  const available = ITEMS.filter((item) => !taken.has(item.id));
  const total = available.reduce((sum, item) => sum + item.weight, 0);
  let roll = Math.random() * total;
  for (const item of available) {
    roll -= item.weight;
    if (roll < 0) return item;
  }
  return available[available.length - 1] ?? ITEMS[0];
};

/** One restock: MERCHANT_SLOTS distinct items. Rare items come in single copies. */
export function rollStock(): MerchantSlot[] {
  const taken = new Set<string>();
  const slots: MerchantSlot[] = [];
  for (let i = 0; i < MERCHANT_SLOTS; i++) {
    const item = pickItem(taken);
    taken.add(item.id);
    const qty = item.rarity >= 2 ? 1 : 1 + Math.floor(Math.random() * 3);
    slots.push({ item: item.id, price: item.price, qty });
  }
  return slots;
}

export function restockMerchant(s: Save, now = Date.now()): Save {
  return {
    ...s,
    merchant: {
      stock: rollStock(),
      nextRestockAt: now + restockIntervalMs(s.upgrades.restock),
      restocks: s.merchant.restocks + 1,
    },
  };
}

/** Buys one copy from a stall slot. Returns the same save if it cannot be bought. */
export function purchaseSlot(s: Save, index: number): Save {
  const slot = s.merchant.stock[index];
  if (!slot || slot.qty < 1 || !ITEM_BY_ID[slot.item] || s.clovers < slot.price) return s;
  const stock = s.merchant.stock.map((entry, i) => (i === index ? { ...entry, qty: entry.qty - 1 } : entry));
  return {
    ...s,
    clovers: s.clovers - slot.price,
    inventory: { ...s.inventory, [slot.item]: (s.inventory[slot.item] ?? 0) + 1 },
    merchant: { ...s.merchant, stock },
  };
}

/** Equip a passive charm from inventory into the loadout. Max 3. */
export function equipCharm(s: Save, id: string): Save {
  if ((s.equippedCharms ?? []).length >= 3) return s;
  if ((s.inventory[id] ?? 0) < 1) return s;
  const inventory = { ...s.inventory };
  inventory[id]--;
  if (inventory[id] <= 0) delete inventory[id];
  return {
    ...s,
    inventory,
    equippedCharms: [...(s.equippedCharms ?? []), id],
  };
}

/** Unequip an active charm and return it back to your pack case. */
export function unequipCharm(s: Save, id: string): Save {
  if (!(s.equippedCharms ?? []).includes(id)) return s;
  const equippedCharms = (s.equippedCharms ?? []).filter((x) => x !== id);
  return {
    ...s,
    equippedCharms,
    inventory: { ...s.inventory, [id]: (s.inventory[id] ?? 0) + 1 },
  };
}

/** Uses one item from the pack. Returns the same save if the item is not owned. */
export function consumeItem(s: Save, id: string, now = Date.now()): Save {
  const item = ITEM_BY_ID[id];
  if (!item) return s;
  if (item.kind === "charm") {
    // Charms are equipped, not consumed!
    return equipCharm(s, id);
  }
  if ((s.inventory[id] ?? 0) < 1) return s;
  const inventory = { ...s.inventory };
  inventory[id] -= 1;
  if (inventory[id] <= 0) delete inventory[id];
  const next: Save = { ...s, inventory };

  switch (id) {
    case "caravanToken":
      return restockMerchant(next, now);
    case "timeSand":
      return { ...next, merchant: { ...s.merchant, nextRestockAt: Math.max(now, s.merchant.nextRestockAt - 5 * MIN) } };
    case "kettle": {
      // Brewmaster Pot: double remaining duration on all active potions!
      const buffs = { ...s.buffs };
      for (const buffId of Object.keys(buffs)) {
        const remaining = buffs[buffId] - now;
        if (remaining > 0) buffs[buffId] = now + remaining * 2;
      }
      return { ...next, buffs };
    }
    case "battery":
      // Voltaic Cell: overclocks your next 100 rolls (manual or auto) at 3x speed!
      return { ...next, perks: { ...s.perks, battery: (s.perks.battery ?? 0) + 100 } };
  }

  if (item.duration) {
    // Stacking a timed potion extends it from whichever is later: now or the current expiry.
    const buffs = { ...s.buffs };
    buffs[id] = Math.max(now, buffs[id] ?? 0) + item.duration;
    return { ...next, buffs };
  }
  return next;
}

/** m:ss countdown, never negative. */
export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const minutes = Math.floor(total / 60);
  return `${minutes}:${String(total % 60).padStart(2, "0")}`;
}

/** "10 MIN", "8.5 MIN" and so on. */
export function formatInterval(ms: number): string {
  return `${(ms / MIN).toFixed(ms % MIN === 0 ? 0 : 1)} MIN`;
}

/* ---------------------------------------------------------
   Duplicate Crafting
   --------------------------------------------------------- */

export type CraftIngredient = { tier: number; variant: Variant; count: number };
export type CraftRecipe = { id: string; ingredients: CraftIngredient[] };

/**
 * Crafting recipes for potions, charms, and tools using duplicate clovers.
 * Each recipe checks save.found[foundKey(tier, variant)] leaving at least 1 copy.
 */
export const CRAFT_RECIPES: CraftRecipe[] = [
  {
    id: "luckElixir",
    ingredients: [{ tier: 1, variant: "normal", count: 12 }], // 12 Uncommon
  },
  {
    id: "gilded",
    ingredients: [
      { tier: 1, variant: "normal", count: 20 }, // 20 Uncommon
      { tier: 2, variant: "normal", count: 4 },  // 4 Rare
    ],
  },
  {
    id: "quickstep",
    ingredients: [
      { tier: 1, variant: "normal", count: 25 }, // 25 Uncommon
      { tier: 2, variant: "normal", count: 8 },  // 8 Rare
    ],
  },
  {
    id: "sunfire",
    ingredients: [
      { tier: 2, variant: "normal", count: 15 }, // 15 Rare
      { tier: 3, variant: "normal", count: 4 },  // 4 Epic
    ],
  },
  {
    id: "potionMulti",
    ingredients: [
      { tier: 3, variant: "normal", count: 12 }, // 12 Epic
      { tier: 4, variant: "normal", count: 2 },  // 2 Legendary
    ],
  },
  {
    id: "caravanToken",
    ingredients: [
      { tier: 3, variant: "normal", count: 16 }, // 16 Epic
      { tier: 4, variant: "normal", count: 3 },  // 3 Legendary
    ],
  },
  {
    id: "timeSand",
    ingredients: [
      { tier: 2, variant: "normal", count: 30 }, // 30 Rare
      { tier: 3, variant: "normal", count: 10 }, // 10 Epic
    ],
  },
  {
    id: "kettle",
    ingredients: [
      { tier: 3, variant: "normal", count: 20 }, // 20 Epic
      { tier: 4, variant: "normal", count: 4 },  // 4 Legendary
    ],
  },
  {
    id: "battery",
    ingredients: [
      { tier: 3, variant: "normal", count: 35 }, // 35 Epic
      { tier: 4, variant: "normal", count: 8 },  // 8 Legendary
    ],
  },
  {
    id: "horseshoe",
    ingredients: [
      { tier: 4, variant: "normal", count: 12 }, // 12 Legendary
      { tier: 5, variant: "normal", count: 2 },  // 2 Mythic
    ],
  },
  {
    id: "magnet",
    ingredients: [
      { tier: 2, variant: "normal", count: 20 }, // 20 Rare
      { tier: 3, variant: "normal", count: 4 },  // 4 Epic
    ],
  },
  {
    id: "lodestone",
    ingredients: [
      { tier: 3, variant: "normal", count: 24 }, // 24 Epic
      { tier: 4, variant: "normal", count: 5 },  // 5 Legendary
    ],
  },
  {
    id: "cursedEye",
    ingredients: [
      { tier: 5, variant: "normal", count: 8 },  // 8 Mythic
      { tier: 6, variant: "normal", count: 2 },  // 2 Divine
      { tier: 0, variant: "cursed", count: 1 },  // 1 Common Cursed
    ],
  },
  {
    id: "emeraldRing",
    ingredients: [
      { tier: 3, variant: "normal", count: 25 }, // 25 Epic
      { tier: 4, variant: "normal", count: 5 },  // 5 Legendary
    ],
  },
  {
    id: "crystalShard",
    ingredients: [
      { tier: 4, variant: "normal", count: 15 }, // 15 Legendary
      { tier: 5, variant: "normal", count: 4 },  // 4 Mythic
      { tier: 0, variant: "crystal", count: 1 }, // 1 Common Crystal
    ],
  },
  {
    id: "gearTooth",
    ingredients: [
      { tier: 3, variant: "normal", count: 15 }, // 15 Epic
    ],
  },
  {
    id: "silverBell",
    ingredients: [
      { tier: 3, variant: "normal", count: 18 }, // 18 Epic
      { tier: 4, variant: "normal", count: 3 },  // 3 Legendary
    ],
  },
  {
    id: "luckyCharm",
    ingredients: [
      { tier: 5, variant: "normal", count: 6 },  // 6 Mythic
      { tier: 6, variant: "normal", count: 3 },  // 3 Divine
      { tier: 7, variant: "normal", count: 1 },  // 1 Cosmic
    ],
  },
  {
    id: "cloverCompass",
    ingredients: [
      { tier: 5, variant: "normal", count: 8 },  // 8 Mythic
      { tier: 6, variant: "normal", count: 4 },  // 4 Divine
      { tier: 7, variant: "normal", count: 1 },  // 1 Cosmic
    ],
  },
  {
    id: "philterStar",
    ingredients: [
      { tier: 5, variant: "normal", count: 10 }, // 10 Mythic
      { tier: 6, variant: "normal", count: 4 },  // 4 Divine
      { tier: 7, variant: "normal", count: 2 },  // 2 Cosmic
    ],
  },
];

export const RECIPE_BY_ID = Object.fromEntries(CRAFT_RECIPES.map((r) => [r.id, r]));

/** Checks if a player has enough duplicates to craft, always leaving at least 1 copy. */
export function canCraft(s: Save, recipeId: string): boolean {
  const recipe = RECIPE_BY_ID[recipeId];
  if (!recipe) return false;
  for (const ing of recipe.ingredients) {
    const key = foundKey(ing.tier, ing.variant);
    const owned = s.found[key] ?? 0;
    // Must keep at least 1 copy so index slot remains unlocked.
    if (owned - ing.count < 1) return false;
  }
  return true;
}

/** Crafts one copy, deducting duplicates and adding to the pack. */
export function craftItem(s: Save, recipeId: string): Save {
  if (!canCraft(s, recipeId)) return s;
  const recipe = RECIPE_BY_ID[recipeId]!;
  const found = { ...s.found };
  for (const ing of recipe.ingredients) {
    const key = foundKey(ing.tier, ing.variant);
    found[key] = (found[key] ?? 0) - ing.count;
  }
  return {
    ...s,
    found,
    inventory: { ...s.inventory, [recipeId]: (s.inventory[recipeId] ?? 0) + 1 },
  };
}
