// @ts-nocheck
import { useMemo, useState, type CSSProperties } from "react";
import { fmt, restockIntervalMs, type Save } from "../game/data";
import { ITEM_BY_ID, ITEMS, KIND_LABEL, RARITY_COLORS, RARITY_HUE, RARITY_NAMES, formatCountdown, formatInterval, formatRestockChance, restockOdds } from "../game/market";
import { Block, BlockButton, CloverImg, PixelIcon, PxBar } from "./ui";
import { Modal } from "./panels";
import { ItemTip } from "./ItemTip";
import { useNow } from "./useNow";

/** The chance of every item appearing in one restock, in the same block style as the index. */
function OddsModal({ onClose }: { onClose: () => void }) {
  const odds = useMemo(restockOdds, []);
  const rows = [...ITEMS].sort((a, b) => (odds[b.id] ?? 0) - (odds[a.id] ?? 0));
  return (
    <Modal
      title="RESTOCK ODDS"
      headTone="gold"
      icon="question"
      onClose={onClose}
      className="odds-modal"
      footer={<span className="tx-label">CHANCE TO SEE EACH ITEM AT LEAST ONCE IN A FRESH 5-ITEM WAGON. RARE FINDS ARE NEVER GUARANTEED.</span>}
    >
      <div className="odds-list">
        {rows.map((item) => {
          const chance = odds[item.id] ?? 0;
          return (
            <Block key={item.id} className="odds-row" faceClassName="odds-row-face" style={{ "--h": RARITY_HUE[item.rarity] } as CSSProperties}>
              <Block tone="dark" className="odds-well" faceClassName="odds-well-face">
                <PixelIcon name={item.icon} />
              </Block>
              <div className="odds-info">
                <span className="tx-stroke odds-name">{item.name}</span>
                <span className="tx-label odds-rarity" style={{ color: RARITY_COLORS[item.rarity] }}>{RARITY_NAMES[item.rarity]} {KIND_LABEL[item.kind]}</span>
                <span className="odds-bar-row">
                  <PxBar value={Math.max(0.02, chance)} className="odds-bar" />
                  <span className="tx-label">{fmt(item.price)} EACH</span>
                </span>
              </div>
              <Block tone={chance >= 0.2 ? "green" : chance >= 0.01 ? "gold" : "dark"} className="odds-chip" faceClassName="odds-chip-face">
                <span className="tx-stroke">{formatRestockChance(chance)}</span>
              </Block>
            </Block>
          );
        })}
      </div>
    </Modal>
  );
}

/** The merchant's stock: a live restock countdown plus the goods on the table. */
export function MerchantSection({ save, onBuy }: { save: Save; onBuy: (index: number) => void }) {
  const [oddsOpen, setOddsOpen] = useState(false);
  const now = useNow(1000);
  const remaining = save.merchant.nextRestockAt - now;
  const interval = restockIntervalMs(save.upgrades.restock);
  const stock = save.merchant.stock;

  return (
    <div className="mk">
      <div className="mk-top">
        <Block tone="dark" className="mk-timer" faceClassName="mk-timer-face">
          <PixelIcon name="caravan" className="mk-timer-icon" />
          <span className="mk-timer-copy">
            <span className="tx-label">NEXT RESTOCK</span>
            <span className="tx-stroke mk-timer-value">{formatCountdown(remaining)}</span>
          </span>
        </Block>
        <Block tone="gold" className="mk-route" faceClassName="mk-timer-face">
          <PixelIcon name="merchant" className="mk-timer-icon" />
          <span className="mk-timer-copy">
            <span className="tx-label">CARAVAN ROUTES</span>
            <span className="tx-stroke mk-route-value">EVERY {formatInterval(interval)}</span>
          </span>
        </Block>
        <BlockButton tone="dark" className="mk-help" faceClassName="mk-help-face" onClick={() => setOddsOpen(true)} aria-label="Show item restock odds" title="Restock odds">
          <PixelIcon name="question" className="mk-help-icon" />
        </BlockButton>
      </div>

      <div className="mk-market-note">
        <span className="tx-stroke">TODAY'S WAGON</span>
        <span className="tx-label">HOVER AN ITEM TO SEE WHAT IT DOES</span>
      </div>

      {stock.length === 0 ? (
        <p className="tx-label mk-empty">THE CARAVAN IS STILL UNPACKING...</p>
      ) : (
        <div className="mk-grid">
          {stock.map((slot, i) => {
            const item = ITEM_BY_ID[slot.item];
            if (!item) return null;
            const sold = slot.qty < 1;
            const canBuy = !sold && save.clovers >= slot.price;
            return (
              <ItemTip key={`${i}-${slot.item}`} item={item} className="mk-card-wrap">
                <Block
                  tone={item.rarity >= 4 ? "tint" : "dark"}
                  className={`mk-card${sold ? " is-sold" : ""}`}
                  faceClassName="mk-card-face"
                  style={{ "--h": RARITY_HUE[item.rarity] } as CSSProperties}
                >
                  {item.rarity >= 4 && <span className="mk-stamp tx-stroke">RARE FIND</span>}
                  <PixelIcon name={item.icon} className={`mk-icon${sold ? " is-sold" : ""}`} />
                  <span className="tx-stroke mk-name">{item.name}</span>
                  <span className="tx-label mk-stock">{sold ? "SOLD OUT" : `IN STOCK x${slot.qty}`}</span>
                  <BlockButton
                    tone={canBuy ? "green" : "metal"}
                    disabled={!canBuy}
                    className="mk-buy"
                    faceClassName="mk-buy-face"
                    onClick={() => onBuy(i)}
                    aria-label={sold ? `${item.name} sold out` : `Buy ${item.name} for ${fmt(slot.price)} clovers`}
                  >
                    <CloverImg tier={0} size="sm" className="buy-clover" />
                    <span className="tx-stroke">{sold ? "GONE" : fmt(slot.price)}</span>
                  </BlockButton>
                </Block>
              </ItemTip>
            );
          })}
        </div>
      )}

      {oddsOpen && <OddsModal onClose={() => setOddsOpen(false)} />}
    </div>
  );
}
