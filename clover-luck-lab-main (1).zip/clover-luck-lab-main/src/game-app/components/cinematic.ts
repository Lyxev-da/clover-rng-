// @ts-nocheck
/**
 * Pixel renderer for the reveal cinematic.
 *
 * The whole backdrop (light rays, glow, shockwaves, ordered dithering and white
 * flashes) is computed per native pixel on a small canvas and scaled up with
 * `image-rendering: pixelated`. Every beam and ring is a chunky pixel, never a
 * blurred gradient, so the scene stays inside the game's pixel art language.
 */
import { CUT_TIMELINE as TL } from "../game/cutscenes";

export const CUT_W = 192;
export const CUT_H = 108;
const CX = CUT_W / 2;
const CY = CUT_H * 0.48;
const RAYS = 12;
/** 4x4 ordered-dither threshold matrix, scaled by 1/16. */
const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

type RGB = [number, number, number];
type Mote = { angle: number; radius: number; speed: number; size: number; tone: number };
type Confetti = { x: number; y: number; fall: number; sway: number; phase: number; size: number; tone: number };

export type Scene = {
  /** Eight-step palette from black through the rarity colour to white. */
  css: string[];
  rgb: RGB[];
  drama: number;
  effects: boolean;
  motes: Mote[];
  confetti: Confetti[];
};

/** Deterministic pseudo-random in [0, 1), so every reveal has the same layout. */
const hash = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
const clamp01 = (n: number) => Math.max(0, Math.min(1, n));
const hexToRgb = (hex: string): RGB => {
  const n = parseInt(hex.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const mix = (a: RGB, b: RGB, t: number): RGB => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

export function createScene(colors: readonly [string, string, string], drama: number, effects: boolean): Scene {
  const [primary, light, deep] = colors.map(hexToRgb);
  const black: RGB = [2, 3, 8];
  const rgb: RGB[] = [
    black,
    mix(black, deep, 0.55),
    deep,
    mix(deep, primary, 0.5),
    primary,
    mix(primary, light, 0.5),
    light,
    [255, 255, 255],
  ];
  const css = rgb.map((c) => `rgb(${c.map(Math.round).join(",")})`);
  const motes: Mote[] = Array.from({ length: 56 }, (_, i) => ({
    angle: hash(i) * Math.PI * 2,
    radius: 36 + hash(i + 100) * 62,
    speed: 0.5 + hash(i + 200),
    size: hash(i + 300) > 0.72 ? 2 : 1,
    tone: 3 + Math.floor(hash(i + 400) * 4),
  }));
  const confetti: Confetti[] = Array.from({ length: 44 }, (_, i) => ({
    x: hash(i + 500) * CUT_W,
    y: -hash(i + 600) * CUT_H,
    fall: 16 + hash(i + 700) * 34,
    sway: 2 + hash(i + 800) * 3,
    phase: hash(i + 900) * Math.PI * 2,
    size: hash(i + 950) > 0.6 ? 2 : 1,
    tone: 4 + Math.floor(hash(i + 960) * 4),
  }));
  return { css, rgb, drama, effects, motes, confetti };
}

/**
 * Draws one frame at `t` milliseconds into the cutscene.
 * With effects off the backdrop is drawn once, without motes, rings or flashes.
 */
export function renderFrame(ctx: CanvasRenderingContext2D, image: ImageData, t: number, scene: Scene) {
  const live = scene.effects;
  const charge = clamp01((t - TL.charge) / (TL.impact - TL.charge));
  const build = clamp01((t - TL.impact) / (TL.reveal - TL.impact));
  const sinceReveal = t - TL.reveal;
  const intensity = 0.8 + scene.drama * 0.1;

  // Rays spin slowly, then faster as the charge builds, then whip around on impact.
  const spin = live ? t * (0.0009 + 0.0024 * charge + 0.006 * build) : 0.6;

  let rayAmp: number;
  let glow: number;
  if (t < TL.charge) {
    rayAmp = (0.22 + 0.3 * clamp01(t / TL.charge)) * intensity;
    glow = 0.45;
  } else if (t < TL.impact) {
    rayAmp = (0.52 + 0.38 * charge) * intensity;
    glow = 0.5 + 0.3 * charge;
  } else if (t < TL.reveal) {
    rayAmp = 0.95 * intensity;
    glow = 0.85;
  } else {
    rayAmp = Math.max(0.5, 1 - sinceReveal / 9000) * intensity;
    glow = 0.7;
  }

  // White flashes: a stuttering strobe during impact, then a decaying hit on reveal.
  let flash = 0;
  if (live && t >= TL.impact && t < TL.reveal) {
    const beat = (t - TL.impact) % 260;
    if (beat < 70) flash = 0.5 + 0.5 * build;
  }
  if (live && sinceReveal >= 0 && sinceReveal < 260) flash = Math.max(flash, 1 - sinceReveal / 260);

  // Expanding rings: a steady pulse while charging, one big shockwave on reveal.
  const rings: number[] = [];
  if (live) {
    if (t >= TL.charge && t < TL.impact) {
      for (let i = 0; i < 9; i++) {
        const age = t - (TL.charge + i * 620);
        if (age >= 0 && age < 1400) rings.push(age * 0.075);
      }
    }
    if (sinceReveal >= 0 && sinceReveal < 1000) rings.push(sinceReveal * 0.15);
  }

  const top = scene.rgb.length - 1;
  const data = image.data;
  for (let y = 0; y < CUT_H; y++) {
    for (let x = 0; x < CUT_W; x++) {
      const dx = x - CX;
      const dy = y - CY;
      const d = Math.sqrt(dx * dx + dy * dy);
      const rayFall = clamp01(1 - d / 118);

      let v = 0.03 + clamp01(1 - d / (CUT_W * 0.42)) * 0.46 * glow;
      if (rayFall > 0) {
        const wedge = Math.max(0, Math.sin(Math.atan2(dy, dx) * RAYS * 0.5 + spin));
        v += Math.pow(wedge, 6) * rayFall * 0.5 * rayAmp;
      }
      v *= 1 - 0.35 * clamp01(d / (CUT_W * 0.5));

      if (flash > 0) v += flash * (1 - v);
      for (const r of rings) {
        if (Math.abs(d - r) < 0.9) v = Math.max(v, 0.9);
      }

      // Ordered dithering turns the gradients into a stippled pixel texture.
      const threshold = BAYER[(x & 3) | ((y & 3) << 2)] / 16 - 0.5;
      const level = Math.max(0, Math.min(top, Math.round(clamp01(v) * top + threshold)));
      const c = scene.rgb[level];
      const o = (y * CUT_W + x) * 4;
      data[o] = c[0];
      data[o + 1] = c[1];
      data[o + 2] = c[2];
      data[o + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);

  if (!live) return;

  // Motes gather into the centre as the charge builds, then burst outward on reveal.
  for (const m of scene.motes) {
    let angle = m.angle;
    let radius: number;
    if (t < TL.charge) {
      radius = m.radius;
      angle += t * 0.0004 * m.speed;
    } else if (t < TL.impact) {
      radius = m.radius * (1 - charge * charge * 0.9);
      angle += t * (0.0012 + 0.003 * charge) * m.speed;
    } else if (t < TL.reveal) {
      radius = 6 + 4 * build;
      angle += t * 0.012 * m.speed;
    } else {
      if (sinceReveal > 1200) continue;
      radius = 8 + sinceReveal * 0.1 * m.speed;
    }
    const x = Math.round(CX + Math.cos(angle) * radius);
    const y = Math.round(CY + Math.sin(angle) * radius);
    ctx.fillStyle = scene.css[m.tone];
    ctx.fillRect(x, y, m.size, m.size);
  }

  // Confetti of the rarity's colours falls after the reveal lands.
  if (sinceReveal > 0) {
    const span = CUT_H + 12;
    for (const c of scene.confetti) {
      const y = ((((c.y + (sinceReveal / 1000) * c.fall) % span) + span) % span) - 6;
      const x = c.x + Math.sin(sinceReveal / 260 + c.phase) * c.sway;
      ctx.fillStyle = scene.css[c.tone];
      ctx.fillRect(Math.round(x), Math.round(y), c.size, c.size);
    }
  }
}
