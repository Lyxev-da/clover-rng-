# Game progression update
- [ ] Restore Settings and clarify upgrade prices.
- [ ] Set Luck / Value / Multi caps to 1000 / 500 / 50 and test them.
- [ ] Add rebirth 3–5 traits with ascending rarity and value, visuals, and index integration.
- [ ] Verify the game and progression screens.