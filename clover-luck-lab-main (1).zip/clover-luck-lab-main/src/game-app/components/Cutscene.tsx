// @ts-nocheck
import { useEffect, useRef, useState, type CSSProperties } from "react";
import { CRYSTAL_VALUE, CURSED_VALUE, TIERS, fmt, fmtOdds, variantBaseOdds } from "../game/data";
import { CUT_LENGTH_MS, CUT_TIMELINE as TL, cutThemeFor } from "../game/cutscenes";
import { sfx } from "../game/sound";
import { Block, CloverImg, RarityText, variantPrefix } from "./ui";
import { CUT_H, CUT_W, createScene, renderFrame } from "./cinematic";
import type { RevealData } from "./panels";

const CRYSTAL_COLORS: [string, string, string] = ["#dff8ff", "#8fd8ff", "#2e6fc7"];
const CURSED_COLORS: [string, string, string] = ["#ff3fb8", "#ffd6f0", "#3d0c35"];
type Stage = "intro" | "charge" | "impact" | "reveal" | "fade";

/** Replaces every digit with a random one, so the odds look like they are still rolling. */
const scramble = (text: string) => text.replace(/\d/g, () => String(Math.floor(Math.random() * 10)));

/**
 * A 15-second, unskippable reveal.
 *
 * Intro (letterbox + "incoming") -> charge (silhouette grows, rays spin, odds
 * scramble, meter fills) -> impact (strobing flashes, hard shake) -> reveal
 * (slam-in rarity, the clover, a name plate, tags and confetti) -> fade out.
 *
 * Stage changes are timed here. The pixel backdrop runs its own frame loop on
 * the same clock, and the on-screen items use CSS delays from the same timeline.
 */
export function Cutscene({ data, drama, effects, onDone }: {
  data: RevealData;
  drama: number;
  effects: boolean;
  onDone: () => void;
}) {
  const t = TIERS[data.tier];
  const crystal = data.variant === "crystal";
  const cursed = data.variant === "cursed";
  const theme = cutThemeFor(t.id);
  const colors = crystal ? CRYSTAL_COLORS : cursed ? CURSED_COLORS : theme.colors;
  const hue = crystal ? 203 : cursed ? 322 : theme.hue;
  const word = crystal ? "SOMETHING CRYSTALLIZES" : cursed ? "A CURSE AWAKENS" : theme.word;
  const line = crystal ? "Ice crystallizes around the clover." : cursed ? "Something ancient has opened its eye." : theme.line;
  const realOdds = `1 IN ${fmtOdds(t.chance * variantBaseOdds(data.variant))}`;

  const [stage, setStage] = useState<Stage>("intro");
  const [rolling, setRolling] = useState(realOdds);
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  // Runs once from mount. Nothing in here can be skipped; the last call ends the cutscene.
  useEffect(() => {
    const timers = [
      window.setTimeout(() => setStage("charge"), TL.charge),
      window.setTimeout(() => setStage("impact"), TL.impact),
      window.setTimeout(() => setStage("reveal"), TL.reveal),
      window.setTimeout(() => setStage("fade"), TL.fade),
      window.setTimeout(() => onDoneRef.current(), CUT_LENGTH_MS),
      window.setTimeout(() => { if (!document.hidden) sfx.impact(drama); }, TL.reveal),
      window.setTimeout(() => {
        if (!document.hidden) sfx.roll(data.tier, data.variant === "shiny", data.crit, crystal, cursed);
      }, TL.reveal + 180),
    ];
    sfx.charge(drama, TL.reveal / 1000);
    rootRef.current?.focus({ preventScroll: true });
    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, []);

  // The odds readout flickers through random digits during the charge.
  useEffect(() => {
    if (stage !== "charge" || !effects) return;
    const id = window.setInterval(() => setRolling(scramble(realOdds)), 70);
    return () => window.clearInterval(id);
  }, [stage, effects, realOdds]);

  // The pixel backdrop: a full frame loop on the cutscene clock.
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;
    const scene = createScene(colors, drama, effects);
    const image = ctx.createImageData(CUT_W, CUT_H);

    if (!effects) {
      renderFrame(ctx, image, TL.reveal + 1500, scene);
      return;
    }
    const start = performance.now();
    let frame = 0;
    const loop = (now: number) => {
      const elapsed = now - start;
      renderFrame(ctx, image, elapsed, scene);
      if (elapsed < CUT_LENGTH_MS) frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frame);
  }, [colors, drama, effects]);

  const shownOdds = stage === "charge" ? rolling : realOdds;
  const style = {
    "--h": hue,
    "--s": 1 + drama,
    "--c1": colors[0],
    "--c2": colors[1],
    "--c3": colors[2],
  } as CSSProperties;

  return (
    <div
      ref={rootRef}
      className={`cs-root phase-${stage} drama-${drama}${crystal ? " is-crystal" : ""}${cursed ? " is-cursed" : ""}`}
      style={style}
      role="dialog"
      aria-modal="true"
      aria-live="polite"
      aria-label={`${variantPrefix(data.variant)}${t.label} clover reveal`}
      tabIndex={-1}
    >
      <div className="cs-world">
        <canvas ref={canvasRef} className="cs-canvas" width={CUT_W} height={CUT_H} aria-hidden="true" />
        <div className="cs-scan" aria-hidden="true" />
        <div className="cs-bar cs-bar-top" aria-hidden="true" />
        <div className="cs-bar cs-bar-bottom" aria-hidden="true" />

        <div className="cs-layer cs-intro" aria-hidden="true">
          <span className="tx-label cs-intro-text">{cursed ? "SOMETHING STIRS" : "INCOMING ROLL"}</span>
        </div>

        <div className="cs-layer cs-charge">
          <span className="tx-stroke cs-word">{word}</span>
          <div className="cs-silhouette-wrap">
            <CloverImg tier={data.tier} locked className="cs-silhouette" />
          </div>
          <span className="tx-stroke cs-odds">{shownOdds}</span>
          <div className="cs-meter" aria-hidden="true"><i /></div>
          <span className="tx-label cs-meter-label">{cursed ? "BINDING" : "CHARGING"}</span>
        </div>

        <div className="cs-layer cs-reveal">
          {data.isNew && (
            <Block tone="red" className="cs-stamp" faceClassName="cs-stamp-face">
              <span className="tx-stroke">FIRST UNLOCK</span>
            </Block>
          )}
          <RarityText tier={data.tier} crystal={crystal} cursed={cursed} animated className="cs-rarity">
            {variantPrefix(data.variant)}{t.label}
          </RarityText>
          <div className="cs-clover-wrap">
            <CloverImg tier={data.tier} variant={data.variant} size="lg" className="cs-clover" animated={effects} effects={effects} />
          </div>
          <Block className="cs-plate" faceClassName="cs-plate-face">
            <span className="tx-stroke cs-name">{t.name.toUpperCase()}</span>
            <span className="cs-line">{line}</span>
          </Block>
          <div className="cs-tags">
            <Block tone="green" className="cs-tag" faceClassName="cs-tag-face">
              <span className="tx-stroke">+{fmt(data.value)}</span>
            </Block>
            {crystal && (
              <Block tone="tint" className="cs-tag" faceClassName="cs-tag-face" style={{ "--h": 203 } as CSSProperties}>
                <span className="tx-stroke">CRYSTAL x{CRYSTAL_VALUE}</span>
              </Block>
            )}
            {cursed && (
              <Block tone="red" className="cs-tag" faceClassName="cs-tag-face">
                <span className="tx-stroke">CURSED x{CURSED_VALUE}</span>
              </Block>
            )}
            {data.crit && (
              <Block tone="gold" className="cs-tag" faceClassName="cs-tag-face">
                <span className="tx-stroke">CRIT x10</span>
              </Block>
            )}
          </div>
          <span className="tx-label cs-odds-final">{realOdds}</span>
        </div>

        <div className="cs-fade" aria-hidden="true" />
      </div>
    </div>
  );
}
