// @ts-nocheck
import { useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { KIND_LABEL, RARITY_COLORS, RARITY_NAMES, type ItemDef } from "../game/market";
import { PixelIcon } from "./ui";

type Anchor = { x: number; y: number; above: boolean };

/**
 * Wraps any element and shows a pixel tooltip for a merchant item on hover or focus.
 * The tip is portalled to <body> and positioned from the element's rect, so modal
 * scroll areas and clip-path block corners can never cut it off.
 */
export function ItemTip({ item, children, className }: { item: ItemDef; children: ReactNode; className?: string }) {
  const [anchor, setAnchor] = useState<Anchor | null>(null);

  const show = (element: HTMLElement) => {
    const rect = element.getBoundingClientRect();
    const above = rect.top > 190;
    setAnchor({ x: rect.left + rect.width / 2, y: above ? rect.top - 8 : rect.bottom + 8, above });
  };
  const hide = () => setAnchor(null);

  return (
    <span
      className={className}
      onMouseEnter={(event) => show(event.currentTarget)}
      onMouseLeave={hide}
      onFocus={(event) => show(event.currentTarget)}
      onBlur={hide}
    >
      {children}
      {anchor && createPortal(
        <div
          className={`tip${anchor.above ? " is-above" : " is-below"}`}
          role="tooltip"
          style={{ left: anchor.x, top: anchor.y }}
        >
          <div className="tip-head">
            <PixelIcon name={item.icon} className="tip-icon" />
            <div className="tip-copy">
              <span className="tx-stroke tip-name">{item.name}</span>
              <span className="tx-label tip-rarity" style={{ color: RARITY_COLORS[item.rarity] }}>{RARITY_NAMES[item.rarity]} {KIND_LABEL[item.kind]}</span>
            </div>
          </div>
          <span className="tip-blurb">{item.blurb}</span>
          <span className="tx-stroke tip-effect">{item.effect}</span>
        </div>,
        document.body,
      )}
    </span>
  );
}
